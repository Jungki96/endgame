import React from "react";
import Layout from "../shared/Layout";

const List = () => {
  return (
    <Layout>
      <div>
        <div>🥕🥕🥕🥕🥕</div>
        <div> 여기 리스트창</div>
        <div>🧡💛💚💙💜</div>
      </div>
    </Layout>
  );
};

export default List;
